// PART 1
// Step 1 - Set our request URL


// Step 2 - Fetch our URL

// Step 3 - Using the .then() method, pass a callback function that receives the response object and returns the Promise with the .json() method



// Step 4 - Add another .then() method passing a callback that will receive our data object


// PART 2
// Step 1 - Remove the callback from Step 4 and replace it with wesGotsDatum

// Step 2 - Write a named function called wesGotsDatum and have it accept an argument called data
// Add a console log to show the data



  // Step 3a - Select and store the #company h2


  // Step 3b - Output the company name from the data object


  // Step 4a - Select and store the #slogan p tag


  // Step 4b - Output the slogan from the data object


  // Step 5a - Select and store the product dimensions (#productDimensions)


  // Step 5b - Store the products data array in a variable called products


  // Step 5c - Iterate through the products

    // Step 5d - Create a new div element


    // Step 5e - Add a sentence that displays the product name and the dimensions


    // Step 5d - Append the new element to the product dimensions element


